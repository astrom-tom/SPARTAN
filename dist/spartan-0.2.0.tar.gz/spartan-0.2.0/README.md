*See [here](https://astrom-tom.github.io/SPARTAN/) to display the documentation.*
